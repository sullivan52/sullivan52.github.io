//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Shayne Sullivan
// Version     : 1.0
// Description : DSA Final Project: Implementation of a Binary Search Tree to
//				 manage and store college courses. Users are able to load a csv
//				 file containing the course catalog, print an alphanumerical 
//				 list of the courses, and search for information on a specific
//				 course.
//============================================================================

# include <iostream>
# include <fstream>
# include <string>
# include <vector>
# include <sstream>
# include <algorithm>

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

struct Course {
	string courseId;
	string courseName;
	vector<string> prerequisites;
};

// Internal structure for the tree
struct Node {
	Course course;
	Node* left;
	Node* right;

	// Default constructor
	Node() {
		left = nullptr;
		right = nullptr;
	}

	// Constructor that accepts a Course object
	Node(Course c) : course(c), left(nullptr), right(nullptr) {}
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

class BinarySearchTree {

private:
	Node* root;

	void insertNode(Node* node, Course course);
	Course searchNode(Node* node, string courseId);
	void printCourseList(Node* node);

public:
	BinarySearchTree();
	void displayCourse(const Course& course);
	void addCourse(Course course);
	void printCourseList();
	Course findCourseById(string courseId);

};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
	// Initialize empty tree
	root = nullptr;
}

/**
 * Display course information
 *
 * @param course The course object containing the course ID, name, and prerequisites
 */
void BinarySearchTree::displayCourse(const Course& course) {
	cout << "Course ID: " << course.courseId << endl;
	cout << "Course Name: " << course.courseName << endl;
	cout << "Prerequisites: ";

	// If there are no prerequisites, output "None"
	if (course.prerequisites.empty()) {
		cout << "None";
	}
	// Else out all prerequisites
	else {
		for (const string& prereq : course.prerequisites) {
			cout << prereq << " ";
		}
	}
	cout << endl;
}

/**
 * Insert a new course into the tree
 *
 * @param course The course object to be added to the tree
 */
void BinarySearchTree::addCourse(Course course) {
	// If the tree is empty, set course as the root
	if (root == nullptr) {
		root = new Node(course);
	}
	// Else add the course to the tree starting from the root
	else {
		insertNode(root, course);
	}

}

/**
 * Helper function to insert a new course into the tree
 *
 * @param node The current node in the tree
 * @param course The course object to be inserted
 */
void BinarySearchTree::insertNode(Node* node, Course course) {
	// If the course ID is less than the current node's course ID
	if (course.courseId < node->course.courseId) {
		if (node->left == nullptr) {
			node->left = new Node(course);  // Correctly set the left child
		}
		else {
			insertNode(node->left, course);  // Recurse left
		}
	}
	// If the course ID is greater than or equal to the current node's course ID
	else {
		if (node->right == nullptr) {
			node->right = new Node(course);  // Correctly set the right child
		}
		else {
			insertNode(node->right, course);  // Recurse right
		}
	}
}

/**
 * Searches the tree for a specific course by its ID
 */
Course BinarySearchTree::findCourseById(string courseId) {
	// Begin the search from the root
	return searchNode(root, courseId);
}

/**
 * Helper function to search for a course by its ID
 *
 * @param node The current node in the tree
 * @param courseId The ID of the course to be found
 * @return The course being searched, or an empty Course object if not found
 */
Course BinarySearchTree::searchNode(Node* node, string courseId) {
	// Start at the root
	Node* cur = root;

	// Keep looping downwards until we find the matching courseId or reach the bottom of the tree
	while (cur != nullptr) {
		// Check if we found the course
		if (courseId == cur->course.courseId) {
			return cur->course;  // Return the found course
		}
		// If the courseId is smaller than the current node's courseId, move left
		else if (courseId < cur->course.courseId) {
			cur = cur->left;
		}
		// If the courseId is larger than the current node's courseId, move right
		else {
			cur = cur->right;
		}
	}

	// If no course is found, return an empty Course object
	return Course();
}

/**
 * Prints the list of courses in the tree in alphanumeric order
 */
void BinarySearchTree::printCourseList() {
	// In order traversal starting from the root
	printCourseList(root);
}

/**
 * Helper function that prints the courses in alphanumeric order using in-order traversal
 *
 * @param node The current node in the tree
 */
void BinarySearchTree::printCourseList(Node* node) {
	if (node != nullptr) {
		printCourseList(node->left);  // Traverse the left subtree
		displayCourse(node->course);  // Output course details
		cout << endl; // Add a new line between courses
		printCourseList(node->right);  // Traverse the right subtree
	}
}

//============================================================================
// Utility Functions for file reading and course creation
//============================================================================

/**
 * Load a file containing the courses
 *
 * @param fileName The name of the file to be read
 * @return A vector containing each line of the file as a string. Returns an empty vector if the file cannot be opened
 */

vector<string> readFile(const string& fileName) {
	vector<string> lines; // Initialize vector to store lines
	ifstream file(fileName);

	// Check if the file was opened successfully
	if (!file.is_open()) {
		return lines; // Returns empty vector if unsuccessful
	}
	string line;

	// Read each line and add it to the vector
	while (getline(file, line)) {
		lines.push_back(line);
	}
	// Close file and return vector
	file.close();
	return lines;
}

/**
 * Parse the input file to create course objects and add them to the tree.
 *
 * @param lines The vector of strings created from the input file.
 * @return The populated binary search tree with course objects.
 */
BinarySearchTree createCourse(const vector<string>lines) {
	BinarySearchTree tree;

	// Parse lines from the vector
	for (const string& line : lines) {
		// Skip empty lines
		if (line.empty()) {
			continue;
		}

		vector<string> tokens; // Create vector to store course variables
		stringstream ss(line);
		string token; // Variable to hold each course variable

		// Split lines by commas and add tokens to vector
		while (getline(ss, token, ',')) {
			if (!token.empty()) { // Only add non-empty tokens
				tokens.push_back(token);
			}
		}

		// Validate that there is at least a courseId and courseName
		if (tokens.size() < 2) {
			cout << "Error: Invalid file format in line: " << line << endl;
			continue; // Skip this line and continue
		}

		// Create course object and assign tokens
		Course course;
		course.courseId = tokens[0];
		course.courseName = tokens[1];
		for (size_t i = 2; i < tokens.size(); ++i) {
			course.prerequisites.push_back(tokens[i]);
		}

		// Add the course to the tree
		tree.addCourse(course);
	}
	return tree;
}

/**
 * The one and only main() method
 */
int main() {
	int choice;
	string courseId;
	BinarySearchTree tree;
	Course course;
	string fileName = "CS 300 ABCU_Advising_Program_Input.csv";
	bool endProgram = false; // Flag to check if the user wants to exit the program
	bool dataLoaded = false; // Flag to check if the data was loaded before trying other commands

	// Main menu loop
	while (!endProgram) {
		cout << "Welcome to the Course Planner.\n" << endl;
		cout << "1. Load Data Structure." << endl;
		cout << "2. Print Course List." << endl;
		cout << "3. Print Course." << endl;
		cout << "9. Exit.\n" << endl;
		cout << "What would you like to do?" << endl;

		// Error handling for non integer values
		if (!(cin >> choice)) {
			cout << "Invalid entry. Please enter a number." << endl << endl;
			cin.clear(); // Clear the error flag
			cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard the input
			continue; // Restart the loop
		}

		cout << endl;
		switch (choice) {

		// Loads the csv file containing the courses
		case 1: {
			cout << "Attempting to load file: " << fileName << endl;
			vector<string> lines = readFile(fileName);
			if (lines.empty()) {
				cout << "Unable to open file." << endl;
			}
			else {
				tree = createCourse(lines);
				dataLoaded = true;
				cout << "File successfully loaded!" << endl;
			}

			break;
		}
		// Print a list of the courses in alphanumeric order
		case 2: {
			if (!dataLoaded) {
				cout << "Please load the course data first." << endl;
			}
			else {
				cout << "Here are the list of courses:\n" << endl;
				tree.printCourseList();
			}
			break;
		}
		// Prompt user for input regarding a certain course and print its details
		case 3: {
			if (!dataLoaded) {
				cout << "Please load the course data first." << endl;
			}
			else {
				cout << "Please enter the Course ID of the course you're looking for:" << endl;
				cin >> courseId;
				cout << endl;

				// Transform input to accept both upper and lowercase letters
				transform(courseId.begin(), courseId.end(), courseId.begin(), ::toupper);

				course = tree.findCourseById(courseId);

				// Validate the course was found
				if (!course.courseId.empty()) {
					cout << courseId << " Information:" << endl;
					tree.displayCourse(course);
				}
				else {
					cout << "We're sorry. No courses matching the ID " << courseId << " were found." << endl;
				}
			}
			break;
		}
		// Terminate program
		case 9: {
			endProgram = true;
			cout << "Goodbye!" << endl;
			break;
		}
		// Handle invalid input
		default: {
			cout << choice << " is not a valid option." << endl;
			break;
		}
		}
		cout << endl; // Newline for clarity
	}
	return 0;
}
