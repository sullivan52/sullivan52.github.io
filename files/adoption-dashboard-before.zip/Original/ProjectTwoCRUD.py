from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Connection Variables
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 33683  # Double-check that this matches your Apporto environment
        DB = 'AAC'  # Database name should match your MongoDB setup
        COL = 'animals'

        # Initialize Connection
        try:
            self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
            self.database = self.client[DB]
            self.collection = self.database[COL]
            print("✅ Connected to MongoDB successfully!")
        except Exception as e:
            print(f"❌ Connection error: {e}")

    def create(self, data):
        """Insert a new document into the database and handle errors."""
        if data and isinstance(data, dict):  # Ensure data is a dictionary
            try:
                result = self.collection.insert_one(data)
                print(f"✅ Success! New document inserted with ID: {result.inserted_id}")
                return result.acknowledged  # Returns True if successful
            except Exception as e:
                print(f"❌ Error inserting document: {e}")
                return False  # Return False if insert fails
        else:
            print("❌ Error: Invalid data format. Expected a dictionary but got", type(data))
            return False  # Return False if input is invalid

    def read(self, query):
        """Queries for documents in the database and handles errors."""
        if query and isinstance(query, dict):  # Ensure query is a dictionary
            try:
                results = self.collection.find(query)  # Retrieves matching documents
                return list(results)  # Converts cursor to a list
            except Exception as e:
                print(f"❌ Error reading from database: {e}")
                return []  # Return empty list if read fails
        else:
            print("❌ Error: Invalid query format. Expected a dictionary but got", type(query))
            return []  # Return empty list if input is invalid
        
    def read_all(self):
        """Retrieve all records from the MongoDB collection."""
        try:
            results = list(self.collection.find({}))  # Convert cursor to a list
            # Replace None values with an empty string to avoid crashes
            for doc in results:
                for key, value in doc.items():
                    if value is None:
                        doc[key] = ""

            return results  # Return cleaned-up list
        except Exception as e:
            print(f"❌ Error reading all records: {e}")
            return []  # Return an empty list if read fails


        
    def update(self, query, new_values, multiple=False):
        """ Update one or more documents in the database """
        if isinstance(query, dict) and isinstance(new_values, dict):  # Ensure inputs are dictionaries
            try:
                update_action = {"$set": new_values}  
                if multiple:
                    result = self.collection.update_many(query, update_action)  # Update multiple
                    print(f"✅ Success! {result.modified_count} document(s) updated.")
                else:
                    result = self.collection.update_one(query, update_action)  # Update one
                    print(f"✅ Success! {result.modified_count} document updated.")
                return result.modified_count  # Returns the number of modified documents
            except Exception as e:
                print(f"❌ Error updating document: {e}")  # Catch any errors
                return 0
        else:
            print("❌ Error: Invalid query or update format. Both must be dictionaries.")
            return 0
        
    def delete(self, query, multiple=False):
        """Delete one or more documents from the database."""
        if isinstance(query, dict):  # Ensure query is a dictionary
            try:
                if multiple:
                    result = self.collection.delete_many(query)  # Delete multiple
                    print(f"✅ Success! {result.deleted_count} document(s) deleted.")
                else:
                    result = self.collection.delete_one(query)  # Delete one
                    print(f"✅ Success! {result.deleted_count} document deleted.")
                return result.deleted_count  # Returns the number of deleted documents
            except Exception as e:
                print(f"❌ Error deleting document: {e}")  # Catch any errors
                return 0
        else:
            print("❌ Error: Invalid query format. Expected a dictionary.")
            return 0
